const mongoose = require('mongoose');

// Định nghĩa cấu trúc của một tài khoản
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // Tên đăng nhập (bắt buộc, không trùng)
    password: { type: String, required: true }                // Mật khẩu (bắt buộc)
});

// Xuất ra để server.js có thể sử dụng
module.exports = mongoose.model('User', UserSchema);