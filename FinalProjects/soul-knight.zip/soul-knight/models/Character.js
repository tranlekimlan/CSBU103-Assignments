// file: models/Character.js
const mongoose = require('mongoose');

const CharacterSchema = new mongoose.Schema({
    name: { type: String, required: true }, // Tên nhân vật
    hp: { type: Number, required: true },   // Máu
    armor: { type: Number, required: true }, // Giáp
    energy: { type: Number, required: true }, // Năng lượng
    image: { type: String, required: true }, // Link ảnh
    pageUrl: String // URL trang chi tiết nhân vật
});

module.exports = mongoose.model('Character', CharacterSchema);